package com.local.samsungtouch;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;

public final class MainActivity extends Activity {
    private WebView webView;
    private RemoteBridge remote;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,17,30));
        getWindow().setNavigationBarColor(Color.rgb(11,17,30));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11,17,30));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return true; }
        });
        remote = new RemoteBridge(this, webView);
        webView.addJavascriptInterface(remote, "AndroidRemote");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        // Let Android's Back button act as Samsung's back key when connected.
        if (remote != null && remote.isConnected()) remote.sendKey("KEY_RETURN");
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (remote != null) remote.shutdown();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidRemote");
            webView.destroy();
        }
        super.onDestroy();
    }
}
