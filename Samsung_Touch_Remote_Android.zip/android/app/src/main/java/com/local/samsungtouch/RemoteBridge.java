package com.local.samsungtouch;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

/**
 * Native Android LAN transport for Samsung's local Tizen remote-control API.
 * No account, cloud relay, tracking or external JS dependencies.
 * The TV typically uses a self-signed TLS certificate on port 8002.
 * Certificate acceptance is only used after validating the host is a private IPv4 address.
 */
public final class RemoteBridge {
    private final Activity activity;
    private final WebView web;
    private final SharedPreferences prefs;
    private final ExecutorService io = Executors.newCachedThreadPool();
    private final ExecutorService writer = Executors.newSingleThreadExecutor();
    private final Object writeLock = new Object();
    private final SecureRandom random = new SecureRandom();
    private final AtomicInteger epoch = new AtomicInteger();
    private volatile Socket socket;
    private volatile OutputStream output;
    private volatile boolean connected = false;
    private volatile String host = "";
    private volatile String tvName = "Samsung Smart TV";
    private final SSLSocketFactory localSsl;

    public RemoteBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
        this.prefs = activity.getSharedPreferences("samsung_touch", Context.MODE_PRIVATE);
        SSLSocketFactory candidate;
        try {
            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager localOnly = new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            };
            ctx.init(null, new X509TrustManager[]{localOnly}, new SecureRandom());
            candidate = ctx.getSocketFactory();
        } catch (Exception ex) { candidate = null; }
        localSsl = candidate;
    }

    public boolean isConnected() { return connected; }

    private void jsCall(String method, String... args) {
        StringBuilder script = new StringBuilder("window.").append(method).append('(');
        for (int i=0;i<args.length;i++) {
            if (i>0) script.append(',');
            script.append(JSONObject.quote(args[i] == null ? "" : args[i]));
        }
        script.append(");");
        final String command = script.toString();
        activity.runOnUiThread(() -> { if (!activity.isFinishing()) web.evaluateJavascript(command, null); });
    }

    private void notifyState(String state, String message, String ip) {
        jsCall("receiveNativeStatus", state, message, ip);
    }

    private static boolean privateIPv4(String addr) {
        if (addr == null) return false;
        String[] p=addr.trim().split("\\.");
        if (p.length!=4) return false;
        int[] n=new int[4];
        for(int i=0;i<4;i++) {
            if (!p[i].matches("[0-9]{1,3}")) return false;
            n[i]=Integer.parseInt(p[i]);
            if(n[i]>255) return false;
        }
        return n[0]==10 || (n[0]==172 && n[1]>=16 && n[1]<=31)
                || (n[0]==192 && n[1]==168) || (n[0]==169 && n[1]==254);
    }

    @JavascriptInterface public void connect(String ip) {
        if (ip == null) return;
        ip=ip.trim();
        if (!privateIPv4(ip)) {
            notifyState("error", "Use um IP local, por exemplo 192.168.1.100.", ip);
            return;
        }
        final String selected=ip;
        int serial=epoch.incrementAndGet();
        connected=false;
        closeSocket();
        host=ip;
        notifyState("connecting", "Preparando conexão segura…", selected);
        io.execute(() -> runConnection(selected,serial));
    }

    private boolean current(int id) { return epoch.get()==id && !activity.isFinishing(); }

    private void runConnection(String ip, int serial) {
        for (int port : new int[]{8002,8001}) {
            if (!current(serial)) return;
            boolean handshakeDone=false;
            Socket s=null;
            try {
                s=openSocket(ip,port);
                if (!current(serial)) { s.close();return; }
                synchronized (writeLock) { socket=s; output=null; }
                InputStream in=new BufferedInputStream(s.getInputStream());
                OutputStream out=new BufferedOutputStream(s.getOutputStream());
                negotiate(in,out,ip,port);
                handshakeDone=true;
                synchronized (writeLock) { output=out; }
                notifyState("connecting", "Olhe a TV e selecione Permitir, se aparecer.", ip);
                s.setSoTimeout(45000);
                while(current(serial)) {
                    byte[] frame=readFrame(in,out);
                    if(frame==null) throw new EOFException("TV encerrou o canal");
                    if(frame.length==0) continue;
                    String txt=new String(frame,StandardCharsets.UTF_8);
                    try {
                        JSONObject event=new JSONObject(txt);
                        String eventName=event.optString("event","");
                        if ("ms.channel.connect".equals(eventName)) {
                            JSONObject data=event.optJSONObject("data");
                            if (data!=null) {
                                String newToken=data.optString("token","");
                                if(!newToken.isEmpty()) prefs.edit().putString("auth_"+ip,newToken).apply();
                            }
                            connected=true;
                            s.setSoTimeout(0);
                            notifyState("connected", ip+" · Conectada",ip);
                        } else if ("ms.channel.unauthorized".equals(eventName)) {
                            throw new SecurityException("Acesso negado na televisão");
                        } else if ("ms.error".equals(eventName) && !connected) {
                            throw new SecurityException("A TV recusou o pedido de controle");
                        }
                    } catch (org.json.JSONException ignore) { /* ignore non-JSON frames */ }
                }
                return;
            } catch (SecurityException deny) {
                if(current(serial)) notifyState("error",deny.getMessage()+". Autorize o celular na TV.",ip);
                return;
            } catch (SocketTimeoutException time) {
                if(current(serial)) {
                    if(handshakeDone) notifyState("error", "Tempo esgotado. Autorize o controle na tela da TV.",ip);
                    else if(port==8001) notifyState("error", "A TV não respondeu. Confira o IP e a rede Wi-Fi.",ip);
                }
                if(handshakeDone) return;
            } catch (Exception err) {
                // After successful pairing, a normal socket closure ends the session.
                if(handshakeDone) {
                    if(current(serial)) notifyState("idle", "Conexão com a TV encerrada. Toque em Conectar.",ip);
                    return;
                }
            } finally {
                synchronized (writeLock) {
                    if(socket==s) { socket=null; output=null; connected=false; }
                }
                if(s!=null) try{s.close();}catch(Exception ignore){}
            }
        }
        if(current(serial)) notifyState("error", "Não foi possível alcançar a TV nas portas 8002 ou 8001. Verifique IP, Wi-Fi e permissões.",ip);
    }

    private Socket openSocket(String ip, int port) throws Exception {
        Socket plain=new Socket();
        try {
            plain.connect(new java.net.InetSocketAddress(ip,port),2500);
            plain.setSoTimeout(4500);
            plain.setTcpNoDelay(true);
            if(port==8001) return plain;
            if(localSsl==null) throw new IOException("TLS indisponível");
            SSLSocket secure=(SSLSocket)localSsl.createSocket(plain,ip,port,true);
            secure.setSoTimeout(4500);
            secure.startHandshake();
            return secure;
        } catch(Exception ex) {
            try{plain.close();}catch(Exception ignored){}
            throw ex;
        }
    }

    private void negotiate(InputStream in, OutputStream out, String ip, int port) throws Exception {
        byte[] nonce=new byte[16];random.nextBytes(nonce);
        String key=Base64.encodeToString(nonce,Base64.NO_WRAP);
        String name=Base64.encodeToString("Samsung Touch Remote".getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
        String path="/api/v2/channels/samsung.remote.control?name="+URLEncoder.encode(name,"UTF-8");
        String token=prefs.getString("auth_"+ip,"");
        if(!token.isEmpty()) path+="&token="+URLEncoder.encode(token,"UTF-8");
        String request="GET "+path+" HTTP/1.1\r\nHost: "+ip+":"+port
                +"\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: "+key
                +"\r\nSec-WebSocket-Version: 13\r\n\r\n";
        out.write(request.getBytes(StandardCharsets.US_ASCII));out.flush();
        ByteArrayOutputStream response=new ByteArrayOutputStream();
        int state=0;
        while(response.size()<16384) {
            int ch=in.read();if(ch<0) throw new EOFException("Sem resposta do WebSocket");
            response.write(ch);
            state=(state==0&&ch=='\r')?1:(state==1&&ch=='\n')?2:(state==2&&ch=='\r')?3:(state==3&&ch=='\n')?4:0;
            if(state==4) break;
        }
        String header=response.toString("ISO-8859-1");
        if(!header.startsWith("HTTP/1.1 101")&&!header.startsWith("HTTP/1.0 101"))
            throw new IOException("WebSocket recusado: "+header.split("\r?\n")[0]);
        String expected=Base64.encodeToString(MessageDigest.getInstance("SHA-1").digest(
                (key+"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)),Base64.NO_WRAP);
        boolean accepted=false;
        for(String line:header.split("\r?\n"))
            if(line.toLowerCase(Locale.US).startsWith("sec-websocket-accept:"))
                accepted=expected.equals(line.substring(line.indexOf(':')+1).trim());
        if(!accepted) throw new IOException("Resposta WebSocket inválida");
    }

    /** Returns data frames; replies to ping, consumes pong, throws on close. */
    private byte[] readFrame(InputStream in,OutputStream out) throws IOException {
        int first=in.read();
        if(first<0) return null;
        int second=in.read();
        if(second<0) return null;
        int opcode=first&0x0F;
        boolean masked=(second&0x80)!=0;
        long len=second&0x7f;
        if(len==126) len=((long)readByte(in)<<8)|readByte(in);
        else if(len==127){len=0;for(int i=0;i<8;i++)len=(len<<8)|readByte(in);}
        if(len<0||len>1024*1024) throw new IOException("WebSocket frame excessivo");
        byte[] mask=null;
        if(masked){mask=new byte[4];readFully(in,mask);}
        byte[] data=new byte[(int)len];readFully(in,data);
        if(masked)for(int i=0;i<data.length;i++)data[i]^=mask[i%4];
        if(opcode==8) return null;
        if(opcode==9){sendFrame(out,0xA,data);return new byte[0];}
        if(opcode==10) return new byte[0];
        if(opcode==1) return data;
        return new byte[0];
    }

    private static int readByte(InputStream in) throws IOException {
        int b=in.read();if(b<0)throw new EOFException("Frame incompleto");return b;
    }
    private static void readFully(InputStream in,byte[] b) throws IOException {
        int n=0;while(n<b.length){int r=in.read(b,n,b.length-n);if(r<0)throw new EOFException();n+=r;}
    }

    /** Client-to-server WebSocket frames MUST be masked (RFC 6455). */
    private void sendFrame(OutputStream out,int opcode,byte[] data) throws IOException {
        synchronized(writeLock){
            out.write(0x80|opcode);
            int length=data.length;
            if(length<=125) out.write(0x80|length);
            else if(length<=65535){out.write(0x80|126);out.write(length>>8);out.write(length);}
            else{out.write(0x80|127);for(int i=7;i>=0;i--)out.write((int)(((long)length>>(8*i))&0xff));}
            byte[] mask=new byte[4];random.nextBytes(mask);out.write(mask);
            byte[] encrypted=data.clone();
            for(int i=0;i<encrypted.length;i++)encrypted[i]^=mask[i%4];
            out.write(encrypted);out.flush();
        }
    }

    private void sendJSON(JSONObject payload) {
        if(!connected)return;
        writer.execute(()->{
            if(!connected)return;
            try{
                OutputStream o=output;
                if(o!=null)sendFrame(o,1,payload.toString().getBytes(StandardCharsets.UTF_8));
            }catch(Exception e){
                if(connected)notifyState("error","Perdeu a conexão com a TV. Conecte novamente.",host);
                connected=false;
                closeSocket();
            }
        });
    }

    private JSONObject command(JSONObject params) {
        JSONObject obj=new JSONObject();
        try{obj.put("method","ms.remote.control");obj.put("params",params);}catch(Exception ignored){}
        return obj;
    }

    @JavascriptInterface public void sendKey(String code) {
        if(code==null||!code.matches("KEY_[A-Z0-9_]{1,35}"))return;
        try{
            JSONObject p=new JSONObject();
            p.put("Cmd","Click");p.put("DataOfCmd",code);
            p.put("Option","false");p.put("TypeOfRemote","SendRemoteKey");
            sendJSON(command(p));
        }catch(Exception ignored){}
    }

    @JavascriptInterface public void sendMouse(String cmd,int x,int y) {
        if(!("Move".equals(cmd)||"LeftClick".equals(cmd)||"RightClick".equals(cmd)))return;
        try{
            JSONObject p=new JSONObject();p.put("Cmd",cmd);p.put("TypeOfRemote","ProcessMouseDevice");
            if("Move".equals(cmd)){
                JSONObject position=new JSONObject();
                position.put("x",Math.max(-450,Math.min(450,x)));
                position.put("y",Math.max(-450,Math.min(450,y)));
                position.put("Time","0");p.put("Position",position);
            }
            sendJSON(command(p));
        }catch(Exception ignored){}
    }

    @JavascriptInterface public void sendText(String text) {
        if(text==null||text.isEmpty())return;
        if(text.length()>1000)text=text.substring(0,1000);
        try{
            JSONObject p=new JSONObject();
            p.put("Cmd",Base64.encodeToString(text.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP));
            p.put("DataOfCmd","base64");p.put("TypeOfRemote","SendInputString");
            sendJSON(command(p));
        }catch(Exception ignored){}
    }

    private void closeSocket(){
        synchronized(writeLock){
            Socket old=socket;socket=null;output=null;
            if(old!=null)try{old.close();}catch(IOException ignored){}
        }
    }

    @JavascriptInterface public void scan() {
        io.execute(()->{
            try{
                List<String> subnets=new ArrayList<>();
                Enumeration<NetworkInterface> nets=NetworkInterface.getNetworkInterfaces();
                while(nets!=null&&nets.hasMoreElements()){
                    NetworkInterface ni=nets.nextElement();
                    if(!ni.isUp()||ni.isLoopback())continue;
                    if(!(ni.getName().startsWith("wlan")||ni.getName().startsWith("eth")||ni.getName().startsWith("wifi")))continue;
                    Enumeration<InetAddress> addresses=ni.getInetAddresses();
                    while(addresses.hasMoreElements()){
                        InetAddress address=addresses.nextElement();
                        if(address instanceof Inet4Address&&privateIPv4(address.getHostAddress())){
                            String a=address.getHostAddress();
                            String subnet=a.substring(0,a.lastIndexOf('.')+1);
                            if(!subnets.contains(subnet))subnets.add(subnet);
                        }
                    }
                }
                if(subnets.isEmpty()){jsCall("receiveNativeScanDone");return;}
                ExecutorService workers=Executors.newFixedThreadPool(28);
                int count=Math.min(subnets.size(),2)*254;
                CountDownLatch latch=new CountDownLatch(count);
                for(int n=0;n<Math.min(subnets.size(),2);n++){
                    final String prefix=subnets.get(n);
                    for(int i=1;i<255;i++){
                        String ip=prefix+i;
                        workers.execute(()->{
                            try{
                                String name=probeTV(ip);
                                if(name!=null)jsCall("receiveNativeDiscovery",ip,name);
                            }catch(Exception ignored){}finally{latch.countDown();}
                        });
                    }
                }
                latch.await(24,TimeUnit.SECONDS);
                workers.shutdownNow();
            }catch(Exception ignored){}
            jsCall("receiveNativeScanDone");
        });
    }

    private String probeTV(String ip) {
        for(int port:new int[]{8001,8002}) {
            try{
                URL url=new URL((port==8001?"http":"https")+"://"+ip+":"+port+"/api/v2/");
                HttpURLConnection http=(HttpURLConnection)url.openConnection();
                http.setConnectTimeout(420);http.setReadTimeout(520);
                if(http instanceof HttpsURLConnection){
                    if(localSsl==null)continue;
                    HttpsURLConnection https=(HttpsURLConnection)http;
                    https.setSSLSocketFactory(localSsl);
                    https.setHostnameVerifier((name,ssl)->privateIPv4(name));
                }
                if(http.getResponseCode()!=200){http.disconnect();continue;}
                byte[] bytes=new byte[8192];
                try(InputStream in=http.getInputStream()){
                    int size=in.read(bytes);
                    if(size<=0)continue;
                    String text=new String(bytes,0,size,StandardCharsets.UTF_8);
                    JSONObject data=new JSONObject(text);
                    JSONObject device=data.optJSONObject("device");
                    String lower=text.toLowerCase(Locale.US);
                    if(device!=null&&(lower.contains("samsung")||lower.contains("tizen"))){
                        String name=device.optString("name","");
                        return name.isEmpty()?"Samsung Smart TV":name;
                    }
                }finally{http.disconnect();}
            }catch(Exception ignored){}
        }
        return null;
    }

    public void shutdown(){epoch.incrementAndGet();connected=false;closeSocket();io.shutdownNow();writer.shutdownNow();}
}
